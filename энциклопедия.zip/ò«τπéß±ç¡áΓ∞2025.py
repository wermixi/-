import tkinter as tk
from tkinter import ttk, font
import json

# Цветовая палитра
COLORS = {
    "light": {
        "bg": "#A0AE91",
        "text": "#15191E",
        "button": "#7A9663",
        "highlight": "#766DA7",
        "secondary": "#556842"
    },
    "dark": {
        "bg": "#304b26",
        "text": "#A0AE91",
        "button": "#766DA7",
        "highlight": "#7A9663",
        "secondary": "#556842"
    }
}

class EncyclopediaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Хочу все знать 2025")
        self.root.geometry("800x600")
        self.current_theme = "light"
        
        # Загрузка данных
        with open("data.json", "r", encoding="utf-8") as f:
            self.data = json.load(f)
        
        # Настройка стилей
        self.setup_styles()
        self.create_main_menu()
    
    def setup_styles(self):
        self.style = ttk.Style()
        
        # Стиль для кнопок
        self.style.configure("TButton", 
                            font=("Helvetica", 12),
                            padding=10)
        
        # Стиль для заголовков
        self.style.configure("Title.TLabel", 
                            font=("Helvetica", 24, "bold"))
        
        # Стиль для статей
        self.style.configure("Article.TLabel", 
                            font=("Helvetica", 14),
                            wraplength=700)
        
        # Стиль для фреймов
        self.style.configure("TFrame", background=COLORS[self.current_theme]["bg"])
    
    def apply_theme(self):
        colors = COLORS[self.current_theme]
        self.root.config(bg=colors["bg"])
        
        # Обновляем стиль ttk
        self.style.configure("TButton", 
                           background=colors["button"],
                           foreground=colors["text"])
        self.style.configure("TLabel", 
                           background=colors["bg"],
                           foreground=colors["text"])
        self.style.configure("Title.TLabel", 
                           background=colors["bg"],
                           foreground=colors["text"])
        self.style.configure("Article.TLabel", 
                           background=colors["bg"],
                           foreground=colors["text"])
        self.style.configure("TFrame", 
                           background=colors["secondary"])
        
        # Обновляем обычные tk виджеты
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Button):
                widget.config(bg=colors["button"], fg=colors["text"])
            elif isinstance(widget, tk.Label):
                widget.config(bg=colors["bg"], fg=colors["text"])
            elif isinstance(widget, tk.Frame):
                widget.config(bg=colors["secondary"])
    
    def toggle_theme(self):
        self.current_theme = "dark" if self.current_theme == "light" else "light"
        self.apply_theme()
    
    def create_main_menu(self):
        # Очищаем текущие виджеты
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Заголовок
        title_label = ttk.Label(self.root, text="Хочу все знать 2025", style="Title.TLabel")
        title_label.pack(pady=20)
        
        # Кнопка темы
        theme_btn = ttk.Button(self.root, text="Сменить тему", command=self.toggle_theme)
        theme_btn.pack(pady=10)
        
        # Алфавитная панель
        alphabet_frame = ttk.Frame(self.root)
        alphabet_frame.pack(pady=20)
        
        # Исключаем Ъ, Ы, Ь
        excluded_letters = {"Ъ", "Ы", "Ь"}
        letters = [letter for letter in "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЭЮЯ" if letter not in excluded_letters]
        
        for i in range(0, len(letters), 6):
            row_frame = ttk.Frame(alphabet_frame)
            row_frame.pack()
            
            for letter in letters[i:i+6]:
                btn = tk.Button(
                    row_frame, 
                    text=letter, 
                    width=4, 
                    height=2,
                    command=lambda l=letter: self.show_letter_articles(l),
                    font=("Helvetica", 14, "bold")
                )
                btn.pack(side=tk.LEFT, padx=5, pady=5)
        
        self.apply_theme()
    
    def show_letter_articles(self, letter):
        articles_window = tk.Toplevel(self.root)
        articles_window.title(f"Статьи на букву {letter}")
        articles_window.geometry("600x500")
        
        # Заголовок
        title_label = ttk.Label(
            articles_window, 
            text=f"Статьи на букву {letter}", 
            style="Title.TLabel"
        )
        title_label.pack(pady=20)
        
        # Список статей
        articles_frame = ttk.Frame(articles_window)
        articles_frame.pack(pady=10)
        
        if letter not in self.data:
            ttk.Label(articles_frame, text="Нет статей").pack()
        else:
            for article in self.data[letter]:
                btn = tk.Button(
                    articles_frame,
                    text=article,
                    command=lambda a=article, l=letter: self.show_article(l, a),
                    width=30,
                    height=2
                )
                btn.pack(pady=5)
        
        # Кнопка назад
        back_btn = ttk.Button(
            articles_window, 
            text="Назад", 
            command=articles_window.destroy
        )
        back_btn.pack(pady=20)
        
        # Применяем тему
        self.apply_theme_to_window(articles_window)
    
    def show_article(self, letter, article):
        article_window = tk.Toplevel(self.root)
        article_window.title(article)
        article_window.geometry("800x600")
        
        # Заголовок
        title_label = ttk.Label(
            article_window, 
            text=article, 
            style="Title.TLabel"
        )
        title_label.pack(pady=20)
        
        # Текст статьи
        content_label = ttk.Label(
            article_window,
            text=self.data[letter][article],
            style="Article.TLabel",
            justify=tk.LEFT
        )
        content_label.pack(pady=20, padx=20)
        
        # Кнопка назад
        back_btn = ttk.Button(
            article_window, 
            text="Назад", 
            command=article_window.destroy
        )
        back_btn.pack(pady=20)
        
        # Применяем тему
        self.apply_theme_to_window(article_window)
    
    def apply_theme_to_window(self, window):
        colors = COLORS[self.current_theme]
        window.config(bg=colors["bg"])
        
        for widget in window.winfo_children():
            if isinstance(widget, tk.Button):
                widget.config(bg=colors["button"], fg=colors["text"])
            elif isinstance(widget, tk.Label):
                widget.config(bg=colors["bg"], fg=colors["text"])
            elif isinstance(widget, tk.Frame):
                widget.config(bg=colors["secondary"])
            elif isinstance(widget, ttk.Button):
                widget.configure(style="TButton")
            elif isinstance(widget, ttk.Label):
                if "Title" in str(widget.configure()):
                    widget.configure(style="Title.TLabel")
                elif "Article" in str(widget.configure()):
                    widget.configure(style="Article.TLabel")
                else:
                    widget.configure(style="TLabel")
            elif isinstance(widget, ttk.Frame):
                widget.configure(style="TFrame")

if __name__ == "__main__":
    root = tk.Tk()
    app = EncyclopediaApp(root)
    root.mainloop()